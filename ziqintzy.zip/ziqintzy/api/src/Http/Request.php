<?php
declare(strict_types=1);
namespace Api\Http;

final class Request
{
    public array $attributes = [];
    public string $ip;   // diisi CloudflareMiddleware setelah divalidasi

    public function __construct(
        public readonly string $method,
        public readonly string $path,
        public readonly array $headers,
        public readonly string $body,
        public readonly string $peer,   // REMOTE_ADDR: koneksi TCP, tidak bisa dipalsukan
    ) {
        $this->ip = $peer;
    }

    public static function fromGlobals(): self
    {
        $headers = function_exists('getallheaders') ? array_change_key_case(getallheaders()) : [];
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        return new self(
            strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            rtrim($path, '/') ?: '/',
            $headers,
            (string) file_get_contents('php://input', false, null, 0, 1_048_576), // max 1MB
            $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
        );
    }

    public function header(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }

    /** @return array<string,mixed> */
    public function json(): array
    {
        try {
            $d = json_decode($this->body, true, 8, JSON_THROW_ON_ERROR);
            return is_array($d) ? $d : [];
        } catch (\JsonException) {
            return [];
        }
    }
}
