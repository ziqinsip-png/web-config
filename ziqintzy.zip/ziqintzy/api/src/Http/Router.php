<?php
declare(strict_types=1);
namespace Api\Http;

use Api\Middleware\MiddlewareInterface;

final class Router
{
    private array $routes = [];
    /** @var list<MiddlewareInterface> */
    private array $global = [];

    public function use(MiddlewareInterface $m): void
    {
        $this->global[] = $m;
    }

    /** @param list<MiddlewareInterface> $middleware */
    public function add(string $method, string $pattern, callable $handler, array $middleware = []): void
    {
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[A-Za-z0-9_-]+)', $pattern) . '$#D';
        $this->routes[] = [$method, $regex, $handler, $middleware];
    }

    public function dispatch(Request $req): Response
    {
        $allowed = [];
        foreach ($this->routes as [$method, $regex, $handler, $mw]) {
            if (!preg_match($regex, $req->path, $m)) continue;
            if ($method !== $req->method) { $allowed[] = $method; continue; }

            $params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
            $core = fn (Request $r): Response => $handler($r, $params);
            return $this->pipeline([...$this->global, ...$mw], $core)($req);
        }

        // OPTIONS / 404 / 405 tetap melewati middleware global (cek Cloudflare + CORS)
        $fallback = match (true) {
            $req->method === 'OPTIONS' => new Response(204),
            $allowed !== []            => new Response(405, ['error' => 'method_not_allowed'],
                                                       ['Allow' => implode(', ', array_unique($allowed))]),
            default                    => new Response(404, ['error' => 'not_found']),
        };
        return $this->pipeline($this->global, fn () => $fallback)($req);
    }

    private function pipeline(array $stack, callable $core): callable
    {
        return array_reduce(
            array_reverse($stack),
            fn (callable $next, MiddlewareInterface $m) => fn (Request $r): Response => $m->handle($r, $next),
            $core
        );
    }
}
