<?php
declare(strict_types=1);
namespace Api\Http;

final class Response
{
    public function __construct(public int $status = 200, public array $data = [], public array $headers = []) {}

    public static function json(array $data, int $status = 200, array $headers = []): self
    {
        return new self($status, $data, $headers);
    }

    public function send(): never
    {
        http_response_code($this->status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');   // jangan sampai di-cache CDN
        foreach ($this->headers as $k => $v) {
            header("$k: $v");
        }
        if ($this->status !== 204) {
            echo json_encode($this->data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        }
        exit;
    }
}
