<?php
declare(strict_types=1);
namespace Api\Controllers;

use Api\Http\{Request, Response};
use Shared\Database\SafePdo;

final class DataController
{
    public function __construct(private readonly SafePdo $db) {}

    public function index(Request $r, array $params = []): Response
    {
        $uid  = (int) $r->attributes['claims']['sub'];
        $rows = $this->db->select(
            'SELECT id, amount, note, created_at FROM transactions WHERE user_id = :uid ORDER BY created_at DESC LIMIT 50',
            ['uid' => $uid]
        );
        return Response::json(['data' => $rows]);
    }

    /** Endpoint sensitif: dilindungi BearerAuth + TOTP. */
    public function create(Request $r, array $params = []): Response
    {
        $uid  = (int) $r->attributes['claims']['sub'];
        $body = $r->json();

        $amount = $body['amount'] ?? null;
        $note   = trim((string) ($body['note'] ?? ''));
        if (!is_int($amount) || $amount === 0 || abs($amount) > 1_000_000_000_000 || mb_strlen($note) > 255) {
            return Response::json(['error' => 'validation_failed'], 422);
        }

        $this->db->execute(
            'INSERT INTO transactions (user_id, amount, note, created_at) VALUES (:uid, :amt, :note, NOW())',
            ['uid' => $uid, 'amt' => $amount, 'note' => $note]
        );
        return Response::json(['id' => (int) $this->db->lastId()], 201);
    }
}
