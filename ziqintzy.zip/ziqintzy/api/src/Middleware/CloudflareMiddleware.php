<?php
declare(strict_types=1);
namespace Api\Middleware;

use Api\Http\{Request, Response};
use Shared\Net\CloudflareIp;

/** Lapis 3: pastikan request benar-benar lewat Cloudflare, lalu percaya CF-Connecting-IP. */
final class CloudflareMiddleware implements MiddlewareInterface
{
    /** @param list<string> $trustedLocal mis. ['127.0.0.1','::1'] jika memakai cloudflared tunnel */
    public function __construct(
        private readonly CloudflareIp $cf,
        private readonly array $trustedLocal = [],
    ) {}

    public function handle(Request $request, callable $next): Response
    {
        $peer   = $request->peer;
        $fromCf = $this->cf->isCloudflare($peer) || in_array($peer, $this->trustedLocal, true);

        if (!$fromCf) {
            return Response::json(['error' => 'forbidden'], 403);   // bypass Cloudflare -> tolak
        }

        $ip = trim($request->header('cf-connecting-ip') ?? '');
        if ($ip === '' || !$this->cf->validPublicIp($ip)) {
            return Response::json(['error' => 'bad_request'], 400);
        }

        $request->ip = $ip;
        return $next($request);
    }
}
