<?php
declare(strict_types=1);
namespace Api\Middleware;

use Api\Http\{Request, Response};
use Shared\Crypto\Totp;
use Shared\Security\RateLimiter;

/**
 * Wajib 2FA untuk endpoint sensitif. Rate limit PER AKUN tetap di PHP:
 * Cloudflare hanya membatasi per IP, serangan terdistribusi ke satu akun hanya
 * bisa dihentikan dengan counter per akun (ruang TOTP cuma 1 juta kombinasi).
 */
final class TotpMiddleware implements MiddlewareInterface
{
    public function __construct(
        private readonly Totp $totp,
        private readonly TotpSecretProvider $secrets,
        private readonly RateLimiter $limiter,
    ) {}

    public function handle(Request $request, callable $next): Response
    {
        $claims = $request->attributes['claims'] ?? null;
        if ($claims === null) {
            return Response::json(['error' => 'unauthorized'], 401);
        }
        $uid = (int) $claims['sub'];

        if (!$this->limiter->hit("totp:u:$uid", 5, 300) || !$this->limiter->hit("totp:ip:{$request->ip}", 20, 300)) {
            return Response::json(['error' => 'too_many_attempts'], 429, ['Retry-After' => '300']);
        }

        $secret = $this->secrets->secretFor($uid);
        $code   = $request->header('x-totp-code') ?? '';
        $step   = $secret !== null ? $this->totp->verify($secret, $code, $this->secrets->lastStep($uid)) : null;

        if ($step === null || !$this->secrets->claimStep($uid, $step)) {
            return Response::json(['error' => 'invalid_totp'], 403);
        }

        $this->limiter->reset("totp:u:$uid");
        return $next($request);
    }
}
