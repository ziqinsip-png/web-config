<?php
declare(strict_types=1);
namespace Api\Middleware;

interface TotpSecretProvider
{
    /** Secret TOTP (sudah didekripsi) atau null jika user belum mengaktifkan 2FA. */
    public function secretFor(int $userId): ?string;

    public function lastStep(int $userId): int;

    /** Klaim step secara ATOMIK. false jika step sudah dipakai (replay / race). */
    public function claimStep(int $userId, int $step): bool;
}
