<?php
declare(strict_types=1);
namespace Api\Middleware;

use Api\Http\{Request, Response};

final class CorsMiddleware implements MiddlewareInterface
{
    private const ALLOWED = [
        'https://app.ziqintzy.my.id',
        'https://admin.ziqintzy.my.id',
    ];

    public function handle(Request $request, callable $next): Response
    {
        $origin = $request->header('origin');
        $cors   = ['Vary' => 'Origin'];

        if ($origin !== null) {
            if (!in_array($origin, self::ALLOWED, true)) {   // exact match, tanpa regex/wildcard
                return Response::json(['error' => 'origin_not_allowed'], 403, $cors);
            }
            $cors += [
                'Access-Control-Allow-Origin'  => $origin,
                'Access-Control-Allow-Methods' => 'GET, POST, PUT, PATCH, DELETE',
                'Access-Control-Allow-Headers' => 'Authorization, Content-Type, X-TOTP-Code',
                'Access-Control-Max-Age'       => '600',
            ];   // tanpa Allow-Credentials: memakai Bearer token, bukan cookie
        }

        if ($request->method === 'OPTIONS') {
            return new Response(204, [], $cors);
        }

        $response = $next($request);
        $response->headers = $cors + $response->headers;
        return $response;
    }
}
