<?php
declare(strict_types=1);
namespace Api\Middleware;

use Api\Http\{Request, Response};

interface MiddlewareInterface
{
    public function handle(Request $request, callable $next): Response;
}
