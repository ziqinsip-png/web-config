<?php
declare(strict_types=1);
namespace Api\Middleware;

use Api\Http\{Request, Response};
use Shared\Crypto\TokenVerifier;

final class BearerAuthMiddleware implements MiddlewareInterface
{
    public function __construct(private readonly TokenVerifier $verifier, private readonly \Redis $redis) {}

    public function handle(Request $request, callable $next): Response
    {
        $h = $request->header('authorization') ?? '';
        if (!preg_match('/^Bearer ([A-Za-z0-9_\-.]{20,2048})$/', $h, $m)) {
            return $this->unauthorized();
        }
        $claims = $this->verifier->verify($m[1]);
        if ($claims === null || $this->redis->exists('revoked:' . $claims['jti'])) {
            return $this->unauthorized();   // pesan seragam: tidak membocorkan penyebab
        }
        $request->attributes['claims'] = $claims;
        return $next($request);
    }

    private function unauthorized(): Response
    {
        return Response::json(['error' => 'unauthorized'], 401, ['WWW-Authenticate' => 'Bearer']);
    }
}
