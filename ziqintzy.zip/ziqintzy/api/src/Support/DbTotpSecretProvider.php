<?php
declare(strict_types=1);
namespace Api\Support;

use Api\Middleware\TotpSecretProvider;
use Shared\Crypto\SecretBox;
use Shared\Database\SafePdo;

final class DbTotpSecretProvider implements TotpSecretProvider
{
    public function __construct(private readonly SafePdo $db, private readonly SecretBox $box) {}

    public function secretFor(int $userId): ?string
    {
        $enc = $this->db->scalar('SELECT totp_secret_enc FROM users WHERE id = :id', ['id' => $userId]);
        return is_string($enc) && $enc !== '' ? $this->box->decrypt($enc) : null;
    }

    public function lastStep(int $userId): int
    {
        return (int) $this->db->scalar('SELECT totp_last_step FROM users WHERE id = :id', ['id' => $userId]);
    }

    public function claimStep(int $userId, int $step): bool
    {
        // UPDATE atomik: hanya satu request yang bisa memakai step ini
        return $this->db->execute(
            'UPDATE users SET totp_last_step = :s WHERE id = :id AND totp_last_step < :s2',
            ['s' => $step, 'id' => $userId, 's2' => $step]
        ) === 1;
    }
}
