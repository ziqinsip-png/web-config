<?php
declare(strict_types=1);

require __DIR__ . '/../../shared/autoload.php';

use Api\Controllers\DataController;
use Api\Http\{Request, Response, Router};
use Api\Middleware\{BearerAuthMiddleware, CloudflareMiddleware, CorsMiddleware, TotpMiddleware};
use Api\Support\DbTotpSecretProvider;
use Shared\Crypto\{SecretBox, TokenVerifier, Totp};
use Shared\Net\CloudflareIp;
use Shared\Security\RateLimiter;

ini_set('display_errors', '0');

try {
    $root = dirname(__DIR__, 2);

    // Public key (base64) per kid -> mendukung rotasi. API TIDAK pernah memegang private key.
    $publicKeys = [env('TOKEN_KID') => base64_decode(env('TOKEN_PUBLIC_KEY_B64'), true) ?: ''];

    $cf       = new CloudflareIp($root . '/storage/cache/cf_ips.txt');
    $verifier = new TokenVerifier($publicKeys);
    $limiter  = new RateLimiter(redis());
    $secrets  = new DbTotpSecretProvider(db(), new SecretBox(env('APP_ENC_KEY')));

    $router = new Router();
    $router->use(new CloudflareMiddleware($cf, trustedLocal: array_filter(explode(',', env('TRUSTED_LOCAL', '')))));
    $router->use(new CorsMiddleware());

    $auth = new BearerAuthMiddleware($verifier, redis());
    $totp = new TotpMiddleware(new Totp(), $secrets, $limiter);
    $data = new DataController(db());

    $router->add('GET',  '/v1/data',         [$data, 'index'],  [$auth]);
    $router->add('POST', '/v1/transactions', [$data, 'create'], [$auth, $totp]);

    $router->dispatch(Request::fromGlobals())->send();
} catch (Throwable $e) {
    error_log('api_fatal ' . $e::class . ': ' . $e->getMessage());   // detail ke log, bukan ke klien
    Response::json(['error' => 'internal_error'], 500)->send();
}
