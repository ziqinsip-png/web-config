<?php
declare(strict_types=1);
namespace Shared\Database;

use PDO;
use PDOException;
use PDOStatement;

/** Wrapper PDO: semua query lewat prepared statement ASLI, multi-statement ditolak. */
final class SafePdo
{
    private PDO $pdo;

    public function __construct(string $host, string $db, string $user, string $pass)
    {
        $this->pdo = new PDO(
            "mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass,
            [
                PDO::ATTR_ERRMODE                => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES       => false,  // prepared statement asli di server MySQL
                PDO::ATTR_DEFAULT_FETCH_MODE     => PDO::FETCH_ASSOC,
                PDO::ATTR_STRINGIFY_FETCHES      => false,
                PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,  // tolak "a; DROP TABLE b" di level driver
                PDO::ATTR_PERSISTENT             => false,
            ]
        );
    }

    /** @return list<array<string,mixed>> */
    public function select(string $sql, array $params = []): array
    {
        return $this->run($sql, $params)->fetchAll();
    }

    public function one(string $sql, array $params = []): ?array
    {
        $row = $this->run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    public function scalar(string $sql, array $params = []): mixed
    {
        $v = $this->run($sql, $params)->fetchColumn();
        return $v === false ? null : $v;
    }

    public function execute(string $sql, array $params = []): int
    {
        return $this->run($sql, $params)->rowCount();
    }

    public function lastId(): string
    {
        return $this->pdo->lastInsertId();
    }

    public function transaction(callable $fn): mixed
    {
        $this->pdo->beginTransaction();
        try {
            $result = $fn($this);
            $this->pdo->commit();
            return $result;
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    /** Nama kolom / ORDER BY tidak bisa di-bind -> wajib whitelist. */
    public static function ident(string $value, array $allowed): string
    {
        if (!in_array($value, $allowed, true)) {
            throw new \InvalidArgumentException('identifier_not_allowed');
        }
        return '`' . str_replace('`', '``', $value) . '`';
    }

    public static function escapeLike(string $v): string
    {
        return addcslashes($v, '%_\\');
    }

    private function run(string $sql, array $params): PDOStatement
    {
        if (preg_match('/;\s*\S/', $sql)) {   // lapis tambahan di atas driver
            throw new \InvalidArgumentException('multi_statement_rejected');
        }
        try {
            $stmt = $this->pdo->prepare($sql);
            foreach ($params as $k => $v) {
                $stmt->bindValue(
                    is_int($k) ? $k + 1 : ':' . ltrim((string) $k, ':'),
                    $v,
                    match (true) {
                        is_int($v)  => PDO::PARAM_INT,
                        is_bool($v) => PDO::PARAM_BOOL,
                        is_null($v) => PDO::PARAM_NULL,
                        default     => PDO::PARAM_STR,
                    }
                );
            }
            $stmt->execute();
            return $stmt;
        } catch (PDOException $e) {
            error_log('db_error code=' . $e->getCode());   // jangan log parameter (PII/data keuangan)
            throw new \RuntimeException('database_error');
        }
    }
}
