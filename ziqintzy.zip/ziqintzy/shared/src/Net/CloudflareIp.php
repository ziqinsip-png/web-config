<?php
declare(strict_types=1);
namespace Shared\Net;

final class CloudflareIp
{
    /** Fallback bila cache belum ada. Sumber kebenaran: bin/update-cf-ips.php (cron). */
    private const FALLBACK = [
        '173.245.48.0/20','103.21.244.0/22','103.22.200.0/22','103.31.4.0/22','141.101.64.0/18',
        '108.162.192.0/18','190.93.240.0/20','188.114.96.0/20','197.234.240.0/22','198.41.128.0/17',
        '162.158.0.0/15','104.16.0.0/13','104.24.0.0/14','172.64.0.0/13','131.0.72.0/22',
        '2400:cb00::/32','2606:4700::/32','2803:f800::/32','2405:b500::/32','2405:8100::/32',
        '2a06:98c0::/29','2c0f:f248::/32',
    ];

    /** @var list<string> */
    private array $ranges;

    public function __construct(string $cacheFile)
    {
        $lines = is_readable($cacheFile) ? file($cacheFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : false;
        $this->ranges = $lines ?: self::FALLBACK;
    }

    public function isCloudflare(string $ip): bool
    {
        $bin = $this->toBinary($ip);
        if ($bin === null) return false;
        foreach ($this->ranges as $cidr) {
            if ($this->inCidr($bin, $cidr)) return true;
        }
        return false;
    }

    public function validPublicIp(string $ip): bool
    {
        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
    }

    private function toBinary(string $ip): ?string
    {
        $bin = @inet_pton($ip);
        if ($bin === false) return null;
        if (strlen($bin) === 16 && str_starts_with($bin, "\0\0\0\0\0\0\0\0\0\0\xff\xff")) {
            return substr($bin, 12);
        }
        return $bin;
    }

    private function inCidr(string $ipBin, string $cidr): bool
    {
        [$subnet, $bits] = explode('/', $cidr) + [1 => null];
        $subBin = @inet_pton((string) $subnet);
        if ($subBin === false || $bits === null || strlen($subBin) !== strlen($ipBin)) return false;

        $bits  = (int) $bits;
        $bytes = intdiv($bits, 8);
        $rem   = $bits % 8;
        if ($bytes > 0 && substr($ipBin, 0, $bytes) !== substr($subBin, 0, $bytes)) return false;
        if ($rem > 0) {
            $mask = (0xFF << (8 - $rem)) & 0xFF;
            if ((ord($ipBin[$bytes]) & $mask) !== (ord($subBin[$bytes]) & $mask)) return false;
        }
        return true;
    }
}
