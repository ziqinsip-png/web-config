<?php
declare(strict_types=1);
namespace Shared\Security;

final class RateLimiter
{
    public function __construct(private readonly \Redis $redis) {}

    /** @return bool true jika masih diizinkan */
    public function hit(string $key, int $max, int $windowSec): bool
    {
        $k = 'rl:' . $key;
        $this->redis->set($k, 0, ['nx', 'ex' => $windowSec]);
        return $this->redis->incr($k) <= $max;
    }

    public function reset(string $key): void
    {
        $this->redis->del('rl:' . $key);
    }
}
