<?php
declare(strict_types=1);
namespace Shared\Crypto;

/** Enkripsi at-rest (mis. secret TOTP) dengan XSalsa20-Poly1305. Key 32 byte dari env (base64). */
final class SecretBox
{
    private string $key;

    public function __construct(string $b64Key)
    {
        $k = base64_decode($b64Key, true);
        if ($k === false || strlen($k) !== SODIUM_CRYPTO_SECRETBOX_KEYBYTES) {
            throw new \InvalidArgumentException('APP_ENC_KEY harus base64 dari 32 byte');
        }
        $this->key = $k;
    }

    public function encrypt(string $plain): string
    {
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return base64_encode($nonce . sodium_crypto_secretbox($plain, $nonce, $this->key));
    }

    public function decrypt(string $b64): ?string
    {
        $raw = base64_decode($b64, true);
        if ($raw === false || strlen($raw) < SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES) {
            return null;
        }
        $plain = sodium_crypto_secretbox_open(
            substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),
            $this->key
        );
        return $plain === false ? null : $plain;
    }
}
