<?php
declare(strict_types=1);
namespace Shared\Crypto;

final class Ed25519Signer
{
    /** @return array{secret:string, public:string} */
    public static function generateKeyPair(): array
    {
        $kp = sodium_crypto_sign_keypair();
        return ['secret' => sodium_crypto_sign_secretkey($kp),
                'public' => sodium_crypto_sign_publickey($kp)];
    }

    public static function sign(string $msg, string $secretKey): string
    {
        return sodium_crypto_sign_detached($msg, $secretKey);
    }

    public static function verify(string $sig, string $msg, string $publicKey): bool
    {
        if (strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES
            || strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            return false;
        }
        return sodium_crypto_sign_verify_detached($sig, $msg, $publicKey);
    }

    public static function b64u(string $bin): string
    {
        return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
    }

    public static function b64uDecode(string $s): ?string
    {
        $bin = base64_decode(strtr($s, '-_', '+/'), true);
        return $bin === false ? null : $bin;
    }
}
