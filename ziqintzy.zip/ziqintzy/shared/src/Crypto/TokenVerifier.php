<?php
declare(strict_types=1);
namespace Shared\Crypto;

final class TokenVerifier
{
    /** @param array<string,string> $publicKeys kid => raw public key (mendukung rotasi key) */
    public function __construct(
        private readonly array $publicKeys,
        private readonly string $issuer = 'auth.ziqintzy.my.id',
        private readonly string $audience = 'api.ziqintzy.my.id',
        private readonly int $leeway = 5,
    ) {}

    /** @return array<string,mixed>|null null = tidak valid */
    public function verify(string $token): ?array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 2 || strlen($token) > 2048) return null;
        [$p, $s] = $parts;

        $json = Ed25519Signer::b64uDecode($p);
        $sig  = Ed25519Signer::b64uDecode($s);
        if ($json === null || $sig === null) return null;

        try {
            $c = json_decode($json, true, 4, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return null;
        }
        if (!is_array($c)) return null;

        $pub = $this->publicKeys[$c['kid'] ?? ''] ?? null;
        if ($pub === null || !Ed25519Signer::verify($sig, $p, $pub)) return null;

        $now = time();
        if (($c['iss'] ?? null) !== $this->issuer
            || ($c['aud'] ?? null) !== $this->audience
            || ($c['exp'] ?? 0) < $now - $this->leeway
            || ($c['nbf'] ?? PHP_INT_MAX) > $now + $this->leeway
            || !isset($c['sub'], $c['jti'])) {
            return null;
        }
        return $c;
    }
}
