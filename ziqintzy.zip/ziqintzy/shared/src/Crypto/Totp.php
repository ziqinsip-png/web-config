<?php
declare(strict_types=1);
namespace Shared\Crypto;

/** TOTP RFC 6238 (HMAC-SHA1, 30 detik, 6 digit) dengan proteksi replay. */
final class Totp
{
    private const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public function __construct(private readonly int $period = 30, private readonly int $digits = 6) {}

    public function generateSecret(): string
    {
        return $this->base32Encode(random_bytes(20));
    }

    public function provisioningUri(string $b32Secret, string $account, string $issuer = 'ziqintzy'): string
    {
        return sprintf('otpauth://totp/%s:%s?secret=%s&issuer=%s&digits=%d&period=%d',
            rawurlencode($issuer), rawurlencode($account), $b32Secret, rawurlencode($issuer), $this->digits, $this->period);
    }

    public function code(string $b32Secret, int $step): string
    {
        $key  = $this->base32Decode($b32Secret);
        $hmac = hash_hmac('sha1', pack('J', $step), $key, true);
        $o    = ord($hmac[19]) & 0x0F;
        $bin  = ((ord($hmac[$o]) & 0x7F) << 24) | (ord($hmac[$o + 1]) << 16)
              | (ord($hmac[$o + 2]) << 8) | ord($hmac[$o + 3]);
        return str_pad((string) ($bin % (10 ** $this->digits)), $this->digits, '0', STR_PAD_LEFT);
    }

    /** @return int|null time-step yang cocok, null jika gagal / replay */
    public function verify(string $b32Secret, string $input, int $lastUsedStep = 0, int $window = 1): ?int
    {
        if (!preg_match('/^\d{' . $this->digits . '}$/', $input)) return null;
        $current = intdiv(time(), $this->period);
        $matched = null;
        for ($i = -$window; $i <= $window; $i++) {   // loop penuh, tanpa early-exit
            $step = $current + $i;
            if (hash_equals($this->code($b32Secret, $step), $input) && $step > $lastUsedStep) {
                $matched = $step;
            }
        }
        return $matched;
    }

    private function base32Encode(string $bin): string
    {
        $bits = '';
        foreach (str_split($bin) as $ch) $bits .= str_pad(decbin(ord($ch)), 8, '0', STR_PAD_LEFT);
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            $out .= self::ALPHABET[bindec(str_pad($chunk, 5, '0'))];
        }
        return $out;
    }

    private function base32Decode(string $b32): string
    {
        $bits = '';
        foreach (str_split(strtoupper(rtrim($b32, '='))) as $ch) {
            $bits .= str_pad(decbin((int) strpos(self::ALPHABET, $ch)), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) $out .= chr(bindec($byte));
        }
        return $out;
    }
}
