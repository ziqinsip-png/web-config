<?php
declare(strict_types=1);
namespace Shared\Crypto;

final class TokenIssuer
{
    public function __construct(
        private readonly string $secretKey,
        private readonly string $kid,
        private readonly string $issuer = 'auth.ziqintzy.my.id',
        private readonly string $audience = 'api.ziqintzy.my.id',
    ) {}

    public function issue(int $userId, array $scopes, bool $mfa, int $ttl = 600): string
    {
        $now = time();
        $p = Ed25519Signer::b64u(json_encode([
            'v' => 1, 'kid' => $this->kid, 'iss' => $this->issuer, 'aud' => $this->audience,
            'sub' => $userId, 'scp' => $scopes, 'mfa' => $mfa,
            'iat' => $now, 'nbf' => $now, 'exp' => $now + $ttl,
            'jti' => bin2hex(random_bytes(16)),
        ], JSON_THROW_ON_ERROR));

        // Signature atas string base64url (bukan JSON) -> tidak ada ambiguitas canonicalization
        return $p . '.' . Ed25519Signer::b64u(Ed25519Signer::sign($p, $this->secretKey));
    }
}
