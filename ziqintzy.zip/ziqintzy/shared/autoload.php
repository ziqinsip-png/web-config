<?php
declare(strict_types=1);

// PSR-4 autoloader manual (tanpa Composer)
spl_autoload_register(static function (string $class): void {
    $map = [
        'Shared\\' => __DIR__ . '/src/',
        'Api\\'    => __DIR__ . '/../api/src/',
        'Auth\\'   => __DIR__ . '/../auth/src/',
    ];
    foreach ($map as $prefix => $dir) {
        if (str_starts_with($class, $prefix)) {
            $file = $dir . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
            if (is_file($file)) {
                require $file;
            }
            return;
        }
    }
});

/** Ambil konfigurasi dari environment (php-fpm pool env / file env di luar docroot). */
function env(string $key, ?string $default = null): string
{
    $v = getenv($key);
    if ($v === false || $v === '') {
        if ($default === null) {
            throw new RuntimeException("Missing env: $key");
        }
        return $default;
    }
    return $v;
}

function redis(): Redis
{
    static $r = null;
    if ($r === null) {
        $r = new Redis();
        $r->connect(env('REDIS_HOST', '127.0.0.1'), (int) env('REDIS_PORT', '6379'));
        if (getenv('REDIS_PASS')) {
            $r->auth(getenv('REDIS_PASS'));
        }
    }
    return $r;
}

function db(): Shared\Database\SafePdo
{
    static $d = null;
    return $d ??= new Shared\Database\SafePdo(env('DB_HOST', '127.0.0.1'), env('DB_NAME'), env('DB_USER'), env('DB_PASS'));
}
