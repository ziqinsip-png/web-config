window.onload = () => {
  window.ui = SwaggerUIBundle({
    url: '/openapi.yaml',
    dom_id: '#swagger-ui',
    persistAuthorization: false,   // jangan simpan token di localStorage
    tryItOutEnabled: false,
  });
};
