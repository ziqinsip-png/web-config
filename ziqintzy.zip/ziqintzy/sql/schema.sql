CREATE TABLE users (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email            VARCHAR(190) NOT NULL UNIQUE,
  password_hash    VARCHAR(255) NOT NULL,           -- argon2id
  totp_secret_enc  TEXT NULL,                       -- SecretBox (terenkripsi)
  totp_last_step   BIGINT UNSIGNED NOT NULL DEFAULT 0,
  is_active        TINYINT(1) NOT NULL DEFAULT 1,
  created_at       DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE transactions (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT UNSIGNED NOT NULL,
  amount      BIGINT NOT NULL,
  note        VARCHAR(255) NOT NULL DEFAULT '',
  created_at  DATETIME NOT NULL,
  INDEX idx_user_created (user_id, created_at),
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- User DB aplikasi: LEAST PRIVILEGE (tanpa DROP/ALTER/FILE/GRANT)
-- CREATE USER 'zq_app'@'127.0.0.1' IDENTIFIED BY '...';
-- GRANT SELECT, INSERT, UPDATE ON zq.users TO 'zq_app'@'127.0.0.1';
-- GRANT SELECT, INSERT ON zq.transactions TO 'zq_app'@'127.0.0.1';
