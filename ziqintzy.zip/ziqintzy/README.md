# ziqintzy.my.id: Native PHP 8.2 microservices (di belakang Cloudflare)

Struktur: `shared/` (library), `auth/` (login, sesi, penerbit token Ed25519), `api/` (REST + middleware), `docs/` (Swagger UI), `deploy/`, `sql/`, `bin/`.

## Setup
1. `php bin/generate-keys.php` -> salin TOKEN_KID, TOKEN_PUBLIC_KEY_B64, APP_ENC_KEY ke env (lihat deploy/env.example).
2. Import `sql/schema.sql`, buat user DB least-privilege.
3. `php bin/update-cf-ips.php`, lalu cron harian.
4. Letakkan swagger-ui-dist di `docs/public/vendor/swagger-ui/` (lihat README di sana).
5. Pasang `deploy/nginx.conf`, aktifkan Authenticated Origin Pulls, firewall 443 hanya ke range Cloudflare.
6. Atur WAF, Rate Limiting, dan Transform Rules (header) di dashboard Cloudflare.
7. Ganti `GANTI_SITE_KEY` di `auth/public/login.html`.

Ekstensi PHP: sodium, pdo_mysql, redis, curl.
Belum ada endpoint pendaftaran / aktivasi TOTP; tambahkan memakai Totp::generateSecret() + SecretBox::encrypt().
