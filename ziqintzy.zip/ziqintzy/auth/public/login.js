// File eksternal (bukan inline) agar CSP script-src 'self' tetap strict.
document.getElementById('f').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const msg = document.getElementById('msg');
  msg.textContent = '';
  try {
    const res = await fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.fromEntries(fd)),
    });
    const data = await res.json();
    if (res.ok) {
      msg.textContent = 'Berhasil masuk.';
      // Serahkan token ke app dengan cara aman sesuai arsitektur frontend kamu.
    } else {
      msg.textContent = 'Gagal: ' + (data.error || res.status);
      if (window.turnstile) window.turnstile.reset();   // token Turnstile sekali pakai
    }
  } catch {
    msg.textContent = 'Terjadi kesalahan jaringan.';
  }
});
