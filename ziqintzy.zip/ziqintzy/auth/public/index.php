<?php
declare(strict_types=1);

require __DIR__ . '/../../shared/autoload.php';

use Auth\{LoginController, SessionManager, Turnstile};
use Shared\Crypto\{TokenIssuer, TokenVerifier};
use Shared\Net\CloudflareIp;
use Shared\Security\RateLimiter;

ini_set('display_errors', '0');

function out(int $status, array $body): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $root = dirname(__DIR__, 2);

    // --- Lapis Cloudflare: harus lewat CF, ambil IP asli ---
    $cf   = new CloudflareIp($root . '/storage/cache/cf_ips.txt');
    $peer = $_SERVER['REMOTE_ADDR'] ?? '';
    $trusted = array_filter(explode(',', env('TRUSTED_LOCAL', '')));
    if (!$cf->isCloudflare($peer) && !in_array($peer, $trusted, true)) {
        out(403, ['error' => 'forbidden']);
    }
    $ip = trim($_SERVER['HTTP_CF_CONNECTING_IP'] ?? '');
    if (!$cf->validPublicIp($ip)) {
        out(400, ['error' => 'bad_request']);
    }
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512);

    // --- Sesi ---
    $session = new SessionManager();
    $session->start();
    $session->validate($ip, $ua);

    $secretKey = base64_decode(file_get_contents($root . '/auth/keys/ed25519.secret.b64') ?: '', true) ?: '';
    $controller = new LoginController(
        db(), $session,
        new Turnstile(env('TURNSTILE_SECRET'), 'auth.ziqintzy.my.id'),
        new RateLimiter(redis()),
        new TokenIssuer($secretKey, env('TOKEN_KID')),
        redis(),
    );

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $path   = rtrim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', '/') ?: '/';

    if ($path === '/login' && $method === 'GET') {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        readfile(__DIR__ . '/login.html');
        exit;
    }

    if ($path === '/login' && $method === 'POST') {
        $isJson = str_starts_with($_SERVER['CONTENT_TYPE'] ?? '', 'application/json');
        $input  = $isJson ? (json_decode(file_get_contents('php://input', false, null, 0, 65536) ?: '', true) ?: []) : $_POST;
        [$status, $body] = $controller->login($ip, $ua, is_array($input) ? $input : []);
        out($status, $body);
    }

    if ($path === '/logout' && $method === 'POST') {
        $claims = [];
        if (preg_match('/^Bearer ([A-Za-z0-9_\-.]{20,2048})$/', $_SERVER['HTTP_AUTHORIZATION'] ?? '', $m)) {
            $pub = base64_decode(env('TOKEN_PUBLIC_KEY_B64'), true) ?: '';
            $claims = (new TokenVerifier([env('TOKEN_KID') => $pub]))->verify($m[1]) ?? [];
        }
        [$status, $body] = $controller->logout($claims);   // revoke jti + hancurkan sesi
        out($status, $body);
    }

    out(404, ['error' => 'not_found']);
} catch (Throwable $e) {
    error_log('auth_fatal ' . $e::class . ': ' . $e->getMessage());
    out(500, ['error' => 'internal_error']);
}
