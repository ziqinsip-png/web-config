Konfigurasi memakai environment variable (lihat `deploy/env.example`). Jangan commit secret.
