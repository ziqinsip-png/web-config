<?php
declare(strict_types=1);
namespace Auth;

use Shared\Crypto\{TokenIssuer};
use Shared\Database\SafePdo;
use Shared\Security\RateLimiter;

final class LoginController
{
    // Hash dummy agar password_verify tetap berjalan saat user tidak ada (waktu respons seragam)
    private ?string $dummyHash = null;

    public function __construct(
        private readonly SafePdo $db,
        private readonly SessionManager $session,
        private readonly Turnstile $turnstile,
        private readonly RateLimiter $limiter,
        private readonly TokenIssuer $issuer,
        private readonly \Redis $redis,
    ) {
    }

    /** @return array{0:int,1:array} [httpStatus, body] */
    public function login(string $ip, string $ua, array $input): array
    {
        if (!$this->turnstile->verify($input['cf-turnstile-response'] ?? null, $ip)) {
            return [403, ['error' => 'challenge_failed']];
        }

        $email = strtolower(trim((string) ($input['email'] ?? '')));
        $pass  = (string) ($input['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $pass === '' || strlen($pass) > 1024) {
            return [401, ['error' => 'invalid_credentials']];
        }

        // Per-akun (bukan hanya per-IP): bantu hentikan credential stuffing terdistribusi
        if (!$this->limiter->hit('login:' . hash('sha256', $email), 10, 900)
            || !$this->limiter->hit("login:ip:$ip", 30, 900)) {
            return [429, ['error' => 'too_many_attempts']];
        }

        $user = $this->db->one('SELECT id, password_hash FROM users WHERE email = :e AND is_active = 1', ['e' => $email]);
        $ok   = password_verify($pass, $user['password_hash'] ?? $this->dummyHash()) && $user !== null;

        if (!$ok) {
            return [401, ['error' => 'invalid_credentials']];   // pesan generik
        }
        if (password_needs_rehash($user['password_hash'], PASSWORD_ARGON2ID)) {
            $this->db->execute('UPDATE users SET password_hash = :h WHERE id = :id',
                ['h' => password_hash($pass, PASSWORD_ARGON2ID), 'id' => (int) $user['id']]);
        }

        $this->limiter->reset('login:' . hash('sha256', $email));
        $this->session->login((int) $user['id'], $ip, $ua);

        // Token pendek (10 menit). mfa=false: aksi sensitif tetap meminta X-TOTP-Code per request.
        $token = $this->issuer->issue((int) $user['id'], ['data:read', 'tx:write'], mfa: false, ttl: 600);
        return [200, ['token' => $token, 'expires_in' => 600]];
    }

    public function logout(array $claimsForRevoke = []): array
    {
        if (isset($claimsForRevoke['jti'], $claimsForRevoke['exp'])) {
            $ttl = max(1, (int) $claimsForRevoke['exp'] - time());
            $this->redis->setex('revoked:' . $claimsForRevoke['jti'], $ttl, '1');
        }
        $this->session->destroy();
        return [200, ['ok' => true]];
    }

    private function dummyHash(): string
    {
        return $this->dummyHash ??= password_hash('dummy-password', PASSWORD_ARGON2ID);
    }
}
