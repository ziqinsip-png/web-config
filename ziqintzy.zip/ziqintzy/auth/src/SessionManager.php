<?php
declare(strict_types=1);
namespace Auth;

final class SessionManager
{
    private const IDLE_TIMEOUT = 900;     // 15 menit
    private const ABSOLUTE_TTL = 28800;   // 8 jam

    public function start(): void
    {
        ini_set('session.use_strict_mode', '1');      // tolak session ID yang tidak dikenal server
        ini_set('session.use_only_cookies', '1');
        ini_set('session.use_trans_sid', '0');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.sid_length', '48');
        ini_set('session.sid_bits_per_character', '6');

        session_name('__Host-sid');                   // prefix __Host-: wajib Secure, Path=/, tanpa Domain
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            // 'domain' sengaja tidak di-set -> cookie tidak bocor ke subdomain lain
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }

    /** @return bool false jika sesi dihancurkan (expired / anomali) */
    public function validate(string $ip, string $userAgent): bool
    {
        if (!isset($_SESSION['uid'])) {
            return true;
        }

        $now     = time();
        $expired = ($now - ($_SESSION['last'] ?? 0)) > self::IDLE_TIMEOUT
                || ($now - ($_SESSION['born'] ?? 0)) > self::ABSOLUTE_TTL;

        // UA harus identik. IP dibandingkan per-subnet (/24 IPv4, /48 IPv6)
        // agar pengguna mobile yang pindah BTS tidak ter-logout terus.
        $anomaly = !hash_equals($_SESSION['ua'] ?? '', hash('sha256', $userAgent))
                || ($_SESSION['net'] ?? '') !== $this->network($ip);

        if ($expired || $anomaly) {
            if ($anomaly) {
                error_log(sprintf('session_anomaly uid=%d old_net=%s new_ip=%s', $_SESSION['uid'], $_SESSION['net'] ?? '-', $ip));
            }
            $this->destroy();
            return false;
        }
        $_SESSION['last'] = $now;
        return true;
    }

    public function login(int $userId, string $ip, string $userAgent): void
    {
        session_regenerate_id(true);                  // ANTI-FIXATION: ID baru + hapus ID lama
        $_SESSION = [
            'uid'  => $userId,
            'born' => time(),
            'last' => time(),
            'ua'   => hash('sha256', $userAgent),
            'net'  => $this->network($ip),
            'csrf' => bin2hex(random_bytes(32)),
        ];
    }

    public function destroy(): void
    {
        $_SESSION = [];
        $p = session_get_cookie_params();
        setcookie(session_name(), '', ['expires' => time() - 3600] + $p);
        session_destroy();
    }

    private function network(string $ip): string
    {
        $bin = inet_pton($ip);
        if ($bin === false) return 'invalid';
        $keep = strlen($bin) === 4 ? 3 : 6;
        return bin2hex(substr($bin, 0, $keep));
    }
}
