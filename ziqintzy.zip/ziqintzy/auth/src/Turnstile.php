<?php
declare(strict_types=1);
namespace Auth;

final class Turnstile
{
    public function __construct(private readonly string $secret, private readonly string $expectedHost) {}

    public function verify(?string $token, string $ip): bool
    {
        if ($token === null || $token === '' || strlen($token) > 2048) return false;

        $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query(['secret' => $this->secret, 'response' => $token, 'remoteip' => $ip]),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 5,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $raw = curl_exec($ch);
        curl_close($ch);
        if ($raw === false) return false;   // fail-closed: Cloudflare down -> tolak

        $r = json_decode($raw, true);
        return is_array($r) && ($r['success'] ?? false) === true
            && ($r['hostname'] ?? '') === $this->expectedHost;
    }
}
